##
# This program prints a pair of initials.
#
# Set the names of the couple.

first = "Rodolfo"
second = "Sally"

# Compute and display the initials.

initials = first[0] + "&" + second[0]
print("\n", initials)
