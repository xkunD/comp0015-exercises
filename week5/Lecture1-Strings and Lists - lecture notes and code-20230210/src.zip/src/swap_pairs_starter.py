def swap_pairs(the_string):
    """
    Returns a string in which pairs of letters are swapped.
    If the string has an odd number of letters, leave the last
    letter in place.
    """

    new_string = ""

         
    
    return new_string
        

def main():
    print(swap_pairs("example"))
    print(swap_pairs("another example."))

if __name__ == "__main__":
    main()
